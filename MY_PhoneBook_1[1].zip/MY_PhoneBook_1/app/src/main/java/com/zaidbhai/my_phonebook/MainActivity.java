package com.zaidbhai.my_phonebook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{

    Button cv_builder;
    Button view_contact;
    Button delete_all;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cv_builder = (Button) findViewById(R.id.cv_builder);
        view_contact = (Button) findViewById(R.id.view_contact);
        delete_all = (Button) findViewById(R.id.delete_all);


        cv_builder.setOnClickListener(this);
        view_contact.setOnClickListener(this);
        delete_all.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == cv_builder) {
            Intent i = new Intent(cv_builder.getContext(), form_cv.class);
            startActivity(i);
        }
        else if (v == view_contact)
        {
            Intent i = new Intent(view_contact.getContext(),form_cv.class);
            startActivity(i);
        }

        else if (v == delete_all)
        {
            Intent i = new Intent(delete_all.getContext(),form_cv.class);
            startActivity(i);
        }


    }
}
