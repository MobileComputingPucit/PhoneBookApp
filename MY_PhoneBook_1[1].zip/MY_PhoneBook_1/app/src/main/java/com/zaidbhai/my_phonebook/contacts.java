package com.zaidbhai.my_phonebook;

import com.orm.SugarRecord;

/**
 * Created by Abdul Majid on 1/26/2018.
 */
public class contacts extends SugarRecord {

    String Name;
    String Phone;
    String Email;

    public contacts()
    {

    }

    /*public contacts(String Name)
    {
            this.Name = Name;
    }*/

    public contacts( String Name, String Phone, String Email )
    {
        this.Name = Name;
        this.Phone = Phone;
        this.Email = Email;
    }

}
