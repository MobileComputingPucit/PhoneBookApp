package com.zaidbhai.my_phonebook;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class form_cv extends AppCompatActivity {

    private EditText OwnerName;
    private EditText Contact_No;
    private EditText Email;
    private Button Save;

    private ListView listView;
    private ArrayAdapter<contacts> adapter;

    Context context = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_cv);

        context = this;

        OwnerName = (EditText) findViewById(R.id.OwnerName);
        Contact_No = (EditText) findViewById(R.id.Contact_No);
        Email = (EditText) findViewById(R.id.Email);
        Save = (Button) findViewById(R.id.Save);

 //       List<contacts> list = contacts.listAll(contacts.class);

        View.OnClickListener save = new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                    //contacts st = new contacts("Usama");
                    //contacts st = new contacts(OwnerName.getText().toString(),Contact_No.getText().toString(),Email.getText().toString());
                    //st.save();

                    Toast.makeText(context,"Information Saved!" ,Toast.LENGTH_SHORT).show();

            }
        };

        Save.setOnClickListener(save);

    }
}
